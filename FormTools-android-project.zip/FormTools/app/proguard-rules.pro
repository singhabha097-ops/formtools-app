# Default rules are enough. AdMob and CameraX ship their own consumer rules.
