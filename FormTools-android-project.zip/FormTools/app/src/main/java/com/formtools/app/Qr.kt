@file:OptIn(ExperimentalMaterial3Api::class)

package com.formtools.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.navigation.NavController
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import kotlinx.coroutines.launch
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

// ---------- QR Scanner ----------
@Composable
fun QrScannerScreen(nav: NavController) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    fun camGranted() = ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    var hasCam by remember { mutableStateOf(camGranted()) }
    var denied by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<String?>(null) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasCam = granted; if (!granted) denied = true
    }
    // Re-check after the user returns from system settings
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) hasCam = camGranted() }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    ToolScaffold("QR Scanner", nav) {
        val r = result
        when {
            !hasCam -> {
                Text("Camera access is needed to scan QR codes. Nothing is recorded or uploaded.")
                if (denied) {
                    Text("Camera permission was denied. Turn it on in Settings to scan.", color = MaterialTheme.colorScheme.error)
                    Button(onClick = {
                        ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
                    }, Modifier.fillMaxWidth()) { Text("Open app settings") }
                } else {
                    Button(onClick = { permLauncher.launch(Manifest.permission.CAMERA) }, Modifier.fillMaxWidth()) { Text("Allow camera") }
                }
            }
            r == null -> {
                Box(Modifier.fillMaxWidth().height(340.dp).clip(RoundedCornerShape(16.dp))) {
                    QrCamera { text -> result = text; History.add(ctx, text) }
                }
                Text("Point the camera at a QR code.")
            }
            else -> {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Result", style = MaterialTheme.typography.labelMedium)
                        SelectionContainer { Text(r, fontWeight = FontWeight.Medium) }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(onClick = { copyText(ctx, r) }, Modifier.weight(1f)) { Text("Copy") }
                    OutlinedButton(onClick = { shareText(ctx, r) }, Modifier.weight(1f)) { Text("Share") }
                }
                if (isHttp(r)) Button(onClick = { openUrl(ctx, r.trim()) }, Modifier.fillMaxWidth()) { Text("Open Link") }
                OutlinedButton(onClick = { result = null }, Modifier.fillMaxWidth()) { Text("Scan again") }
            }
        }
    }
}

@Composable
private fun QrCamera(onResult: (String) -> Unit) {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val latest by rememberUpdatedState(onResult)
    val previewView = remember { PreviewView(ctx) }

    DisposableEffect(owner) {
        val executor = Executors.newSingleThreadExecutor()
        val future = ProcessCameraProvider.getInstance(ctx)
        val found = AtomicBoolean(false)
        var provider: ProcessCameraProvider? = null
        var disposed = false

        future.addListener({
            try {
                if (disposed) return@addListener
                val p = future.get(); provider = p
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                val reader = MultiFormatReader().apply {
                    setHints(mapOf(DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE)))
                }
                analysis.setAnalyzer(executor) { proxy ->
                    try {
                        if (!found.get()) {
                            val plane = proxy.planes[0]
                            val buf = plane.buffer
                            val bytes = ByteArray(buf.remaining()); buf.get(bytes)
                            val src = PlanarYUVLuminanceSource(bytes, plane.rowStride, proxy.height, 0, 0, proxy.width, proxy.height, false)
                            val res = reader.decodeWithState(BinaryBitmap(HybridBinarizer(src)))
                            if (found.compareAndSet(false, true)) previewView.post { latest(res.text) }
                        }
                    } catch (e: Exception) {
                        // no QR code in this frame
                    } finally {
                        reader.reset(); proxy.close()
                    }
                }
                p.unbindAll()
                p.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (e: Exception) {
                previewView.post { toast(ctx, "Couldn't start the camera. Please close other camera apps and try again.") }
            }
        }, ContextCompat.getMainExecutor(ctx))

        onDispose { disposed = true; provider?.unbindAll(); executor.shutdown() }
    }
    AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
}

// ---------- QR Generator ----------
private fun qrBitmap(text: String, size: Int = 640): Bitmap {
    val hints = HashMap<EncodeHintType, Any>()
    hints[EncodeHintType.MARGIN] = 2
    hints[EncodeHintType.CHARACTER_SET] = "UTF-8"
    hints[EncodeHintType.ERROR_CORRECTION] = ErrorCorrectionLevel.M
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, hints)
    val px = IntArray(size * size)
    for (y in 0 until size) for (x in 0 until size) px[y * size + x] = if (m[x, y]) AColor.BLACK else AColor.WHITE
    return Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
}

@Composable
fun QrGeneratorScreen(nav: NavController) {
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var png by remember { mutableStateOf<ByteArray?>(null) }
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    ToolScaffold("QR Generator", nav) {
        OutlinedTextField(
            text, { if (it.length <= 1000) { text = it; png = null; bmp = null } },
            label = { Text("Text or link") }, modifier = Modifier.fillMaxWidth(), minLines = 2
        )
        Button(
            onClick = {
                scope.launch {
                    busy = true; error = null
                    val b = work { qrBitmap(text.trim()) }
                    if (b == null) error = "Couldn't create a QR code from this text. Try shorter text."
                    else { bmp = b; png = work { Img.png(b) } }
                    busy = false
                }
            },
            enabled = text.isNotBlank() && !busy, modifier = Modifier.fillMaxWidth()
        ) { Text("Generate QR code") }
        if (busy) BusyRow("Generating…")
        error?.let { ErrorText(it) }
        val b = bmp; val p = png
        if (b != null && p != null) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Image(remember(b) { b.asImageBitmap() }, "QR code", Modifier.size(260.dp))
            }
            ExportRow(p, "image/png", "QR")
        }
    }
}
