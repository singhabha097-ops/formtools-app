@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.formtools.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// ---------- Scaffolds ----------
class Tab(val route: String, val label: String, val icon: ImageVector)

val tabs = listOf(
    Tab("home", "Home", Icons.Default.Home),
    Tab("history", "History", Icons.AutoMirrored.Filled.List),
    Tab("premium", "Premium", Icons.Default.Star),
    Tab("settings", "Settings", Icons.Default.Settings),
)

/** Top-level screens: bottom navigation bar, NO ads. */
@Composable
fun TabScaffold(nav: NavController, route: String, title: String, content: @Composable (PaddingValues) -> Unit) {
    Scaffold(
        topBar = { TopAppBar(title = { Text(title, fontWeight = FontWeight.Bold) }) },
        bottomBar = {
            NavigationBar {
                tabs.forEach { t ->
                    NavigationBarItem(
                        selected = route == t.route,
                        onClick = {
                            if (route != t.route) nav.navigate(t.route) {
                                popUpTo("home"); launchSingleTop = true
                            }
                        },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label) }
                    )
                }
            }
        },
        content = content
    )
}

/** Tool screens: back button + banner ad at the bottom (hidden for Premium). */
@Composable
fun ToolScaffold(title: String, nav: NavController, content: @Composable ColumnScope.() -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = { nav.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        bottomBar = { BannerAd() }
    ) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            content()
            Spacer(Modifier.height(32.dp)) // keeps buttons well away from the ad
        }
    }
}

@Composable
fun BannerAd() {
    if (Premium.isPremium) return
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(vertical = 4.dp), contentAlignment = Alignment.Center) {
        AndroidView(
            factory = { c ->
                AdView(c).apply {
                    setAdSize(AdSize.BANNER)
                    adUnitId = Ads.BANNER
                    loadAd(AdRequest.Builder().build())
                }
            },
            onRelease = { it.destroy() }
        )
    }
}

// ---------- Pickers & permissions ----------
@Composable
fun rememberImagePicker(onPicked: (Uri) -> Unit): () -> Unit {
    // Android's system photo picker needs no storage permission.
    val l = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { if (it != null) onPicked(it) }
    return { l.launch("image/*") }
}

@Composable
fun rememberMultiImagePicker(onPicked: (List<Uri>) -> Unit): () -> Unit {
    val l = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { onPicked(it) }
    return { l.launch("image/*") }
}

/** Saving needs a permission only on Android 9 and below. Wrap save actions with this. */
@Composable
fun rememberStoragePermissionGate(): (() -> Unit) -> Unit {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<(() -> Unit)?>(null) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val action = pending; pending = null
        if (granted) action?.invoke()
        else toast(ctx, "Storage permission is needed to save files on this Android version. You can still use Share.")
    }
    return { action ->
        if (Build.VERSION.SDK_INT >= 29 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        ) action()
        else { pending = action; launcher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE) }
    }
}

// ---------- Background work ----------
suspend fun <T> work(block: () -> T): T? = withContext(Dispatchers.Default) {
    try { block() } catch (e: Throwable) { null }
}

class PickedImage(val uri: Uri, val bitmap: Bitmap, val sizeBytes: Long)

fun loadPicked(c: android.content.Context, uri: Uri, maxDim: Int): PickedImage? {
    val b = Img.load(c, uri, maxDim) ?: return null
    return PickedImage(uri, b, Img.sizeOf(c, uri))
}

// ---------- Shared widgets ----------
@Composable
fun BusyRow(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
        Text(text.ifBlank { "Working…" })
    }
}

@Composable
fun ErrorText(msg: String) {
    Text(msg, color = MaterialTheme.colorScheme.error)
}

@Composable
fun PickedCard(p: PickedImage) {
    val img = remember(p) { p.bitmap.asImageBitmap() }
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Image(img, null, Modifier.size(72.dp), contentScale = ContentScale.Crop)
            Column {
                Text("Original size", style = MaterialTheme.typography.labelMedium)
                Text(formatSize(p.sizeBytes), fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun SizeCompare(before: Long, after: Long) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Before", style = MaterialTheme.typography.labelMedium)
                Text(formatSize(before), fontWeight = FontWeight.Bold)
            }
            Text("→", style = MaterialTheme.typography.headlineSmall)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("After", style = MaterialTheme.typography.labelMedium)
                Text(formatSize(after), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
fun ResultPreview(bytes: ByteArray) {
    val bmp = remember(bytes) { Img.preview(bytes) }
    bmp?.let {
        Image(remember(it) { it.asImageBitmap() }, null, Modifier.fillMaxWidth().heightIn(max = 240.dp), contentScale = ContentScale.Fit)
    }
}

@Composable
fun KbChips(selected: Int, onSelect: (Int) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(20, 50, 100, 200, 0).forEach { v ->
            FilterChip(selected == v, { onSelect(v) }, label = { Text(if (v == 0) "Custom" else "$v KB") })
        }
    }
}

/** Save + Share. Save counts toward the free daily limit and may trigger an interstitial (max 1 per 2 min). */
@Composable
fun ExportRow(bytes: ByteArray, mime: String, prefix: String) {
    val ctx = LocalContext.current
    val gate = rememberStoragePermissionGate()
    val ext = when (mime) { "application/pdf" -> "pdf"; "image/png" -> "png"; else -> "jpg" }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Button(
            onClick = {
                if (Premium.guardExport(ctx)) gate {
                    val ok = Files.save(ctx, bytes, "${prefix}_${System.currentTimeMillis()}.$ext", mime)
                    if (ok) {
                        Premium.recordExport(ctx)
                        toast(ctx, if (mime == "application/pdf") "Saved in Downloads/FormTools" else "Saved in Pictures/FormTools")
                        ctx.findActivity()?.let { Ads.showInterstitialIfDue(it) }
                    } else toast(ctx, "Couldn't save the file. Check free space and try again.")
                }
            },
            modifier = Modifier.weight(1f)
        ) { Text("Save") }
        OutlinedButton(
            onClick = { Files.share(ctx, bytes, "${prefix}_${System.currentTimeMillis()}.$ext", mime) },
            modifier = Modifier.weight(1f)
        ) { Text("Share") }
    }
}

@Composable
fun UnlockDialog(nav: NavController, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Unlock batch processing") },
        text = { Text("Process many photos at once. Go Premium, or watch one short ad to unlock it until you close the app.") },
        confirmButton = {
            TextButton(onClick = {
                onDismiss()
                ctx.findActivity()?.let { a ->
                    Ads.showRewarded(a) { Premium.sessionUnlock = true; toast(ctx, "Batch processing unlocked for this session") }
                }
            }) { Text("Watch ad") }
        },
        dismissButton = { TextButton(onClick = { onDismiss(); nav.navigate("premium") }) { Text("Go Premium") } }
    )
}
