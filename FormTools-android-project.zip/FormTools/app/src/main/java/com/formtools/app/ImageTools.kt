@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.formtools.app

import android.graphics.Bitmap
import android.graphics.RectF
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max

private fun digits(s: String, max: Int = 5) = s.all { it.isDigit() } && s.length <= max

@Composable
private fun NumberField(value: String, label: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value, { if (digits(it)) onChange(it) }, label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = modifier
    )
}

// ---------- 3. Photo Resize (+ batch) ----------
@Composable
fun PhotoResizeScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val gate = rememberStoragePermissionGate()
    var picked by remember { mutableStateOf<PickedImage?>(null) }
    var preset by remember { mutableIntStateOf(100) }
    var custom by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var result by remember { mutableStateOf<ByteArray?>(null) }
    var showUnlock by remember { mutableStateOf(false) }
    val targetKb = if (preset == 0) (custom.toIntOrNull() ?: 0) else preset

    val pick = rememberImagePicker { uri ->
        scope.launch {
            busy = true; status = "Opening photo…"; error = null; result = null
            val p = work { loadPicked(ctx, uri, 2400) }
            if (p == null) error = "Couldn't open that photo. Please choose a JPG or PNG image." else picked = p
            busy = false
        }
    }

    val pickMany = rememberMultiImagePicker { uris ->
        if (uris.isNotEmpty()) {
            if (targetKb < 5) { error = "Choose a target size of at least 5 KB first."; return@rememberMultiImagePicker }
            gate {
                scope.launch {
                    busy = true; error = null; result = null
                    var done = 0
                    uris.forEachIndexed { i, uri ->
                        status = "Processing ${i + 1} of ${uris.size}…"
                        val ok = work {
                            val b = Img.load(ctx, uri, 2400)
                            if (b == null) false
                            else {
                                val bytes = Img.toTargetSize(b, targetKb * 1024)
                                b.recycle()
                                Files.save(ctx, bytes, "PhotoResize_${System.currentTimeMillis()}_$i.jpg", "image/jpeg")
                            }
                        } ?: false
                        if (ok) done++
                    }
                    busy = false
                    toast(ctx, "Saved $done of ${uris.size} photos in Pictures/FormTools")
                    if (done > 0) ctx.findActivity()?.let { Ads.showInterstitialIfDue(it) }
                }
            }
        }
    }

    ToolScaffold("Photo Resize", nav) {
        Button(onClick = pick, Modifier.fillMaxWidth(), enabled = !busy) {
            Text(if (picked == null) "Choose photo" else "Choose another photo")
        }
        picked?.let { PickedCard(it) }
        Text("Target size", style = MaterialTheme.typography.titleSmall)
        KbChips(preset) { preset = it; result = null }
        if (preset == 0) NumberField(custom, "Custom size (KB)", { custom = it; result = null }, Modifier.fillMaxWidth())
        Button(
            onClick = {
                val p = picked ?: return@Button
                scope.launch {
                    busy = true; status = "Resizing…"; error = null
                    val bytes = work { Img.toTargetSize(p.bitmap, targetKb * 1024) }
                    if (bytes == null) error = "Not enough memory for this photo. Try a smaller one." else result = bytes
                    busy = false
                }
            },
            enabled = picked != null && targetKb >= 5 && !busy, modifier = Modifier.fillMaxWidth()
        ) { Text("Resize") }
        if (busy) BusyRow(status)
        error?.let { ErrorText(it) }
        result?.let { bytes ->
            SizeCompare(picked?.sizeBytes ?: -1, bytes.size.toLong())
            ResultPreview(bytes)
            ExportRow(bytes, "image/jpeg", "PhotoResize")
        }
        HorizontalDivider()
        OutlinedButton(
            onClick = { if (Premium.batchUnlocked) pickMany() else showUnlock = true },
            enabled = !busy, modifier = Modifier.fillMaxWidth()
        ) { Text(if (Premium.batchUnlocked) "Batch: resize many photos" else "🔒 Batch: resize many photos") }
    }
    if (showUnlock) UnlockDialog(nav) { showUnlock = false }
}

// ---------- 4. Image Compress ----------
@Composable
fun CompressScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var picked by remember { mutableStateOf<PickedImage?>(null) }
    var quality by remember { mutableFloatStateOf(60f) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var result by remember { mutableStateOf<ByteArray?>(null) }
    var job by remember { mutableStateOf<Job?>(null) }
    val maxQ = Premium.maxQuality.toFloat()

    val compress: () -> Unit = {
        val p = picked
        if (p != null) {
            job?.cancel()
            job = scope.launch {
                busy = true; error = null
                val q = quality.coerceAtMost(maxQ).toInt()
                val bytes = work { Img.jpeg(Img.flatten(p.bitmap), q) }
                if (bytes == null) error = "Not enough memory for this photo. Try a smaller one." else result = bytes
                busy = false
            }
        }
    }
    val pick = rememberImagePicker { uri ->
        scope.launch {
            busy = true; error = null; result = null
            val p = work { loadPicked(ctx, uri, 2400) }
            if (p == null) error = "Couldn't open that photo. Please choose a JPG or PNG image." else picked = p
            busy = false
        }
    }
    LaunchedEffect(picked) { compress() }

    ToolScaffold("Image Compress", nav) {
        Button(onClick = pick, Modifier.fillMaxWidth()) { Text(if (picked == null) "Choose photo" else "Choose another photo") }
        picked?.let { PickedCard(it) }
        Text("Quality: ${quality.coerceAtMost(maxQ).toInt()}%", style = MaterialTheme.typography.titleSmall)
        Slider(
            value = quality.coerceAtMost(maxQ), onValueChange = { quality = it },
            onValueChangeFinished = { compress() }, valueRange = 10f..maxQ, enabled = picked != null
        )
        if (!Premium.isPremium) Text("Free: up to 80%. Premium unlocks up to 100%.", style = MaterialTheme.typography.bodySmall)
        if (busy) BusyRow("Compressing…")
        error?.let { ErrorText(it) }
        result?.let { bytes ->
            SizeCompare(picked?.sizeBytes ?: -1, bytes.size.toLong())
            ResultPreview(bytes)
            ExportRow(bytes, "image/jpeg", "Compressed")
        }
    }
}

// ---------- 5. Image to PDF ----------
@Composable
private fun Thumb(uri: Uri) {
    val ctx = LocalContext.current
    val img by produceState<ImageBitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) { Img.load(ctx, uri, 160)?.asImageBitmap() }
    }
    Box(Modifier.size(56.dp), contentAlignment = Alignment.Center) {
        img?.let { Image(it, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) } ?: CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
    }
}

@Composable
fun ImageToPdfScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val uris = remember { mutableStateListOf<Uri>() }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var pdf by remember { mutableStateOf<ByteArray?>(null) }

    val pickMany = rememberMultiImagePicker { picked ->
        picked.forEach { if (uris.size < 40 && it !in uris) uris.add(it) }
        if (uris.size >= 40) toast(ctx, "Maximum 40 images per PDF.")
        pdf = null
    }

    ToolScaffold("Image to PDF", nav) {
        Button(onClick = pickMany, Modifier.fillMaxWidth(), enabled = !busy) {
            Text(if (uris.isEmpty()) "Select images" else "Add more images")
        }
        if (uris.isEmpty()) Text("Select one or more images. Pages follow the order below.")
        uris.forEachIndexed { i, u ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Thumb(u)
                    Text("Page ${i + 1}", Modifier.weight(1f).padding(start = 12.dp), fontWeight = FontWeight.Medium)
                    TextButton(onClick = { if (i > 0) { uris.add(i - 1, uris.removeAt(i)); pdf = null } }) { Text("↑") }
                    TextButton(onClick = { if (i < uris.lastIndex) { uris.add(i + 1, uris.removeAt(i)); pdf = null } }) { Text("↓") }
                    TextButton(onClick = { uris.removeAt(i); pdf = null }) { Text("✕") }
                }
            }
        }
        Button(
            onClick = {
                scope.launch {
                    busy = true; error = null
                    val list = uris.toList()
                    val maxDim = if (Premium.isPremium) 1754 else 1240
                    val q = if (Premium.isPremium) 90 else 75
                    val bytes = work { PdfBuilder.build(ctx, list, maxDim, q) }
                    if (bytes == null) error = "Couldn't create the PDF. Please check the images and try again." else pdf = bytes
                    busy = false
                }
            },
            enabled = uris.isNotEmpty() && !busy, modifier = Modifier.fillMaxWidth()
        ) { Text("Create PDF") }
        if (busy) BusyRow("Creating PDF…")
        error?.let { ErrorText(it) }
        pdf?.let { bytes ->
            Text("PDF size: ${formatSize(bytes.size.toLong())}", fontWeight = FontWeight.Bold)
            ExportRow(bytes, "application/pdf", "Images")
        }
    }
}

// ---------- 6. Passport Photo (crop + resize) ----------
class Preset(val name: String, val w: Int, val h: Int, val kb: Int)

// Common defaults. Always check the exact size rules on your form; fields below are editable.
private val presets = listOf(
    Preset("Passport", 413, 531, 200),
    Preset("Aadhaar", 354, 472, 100),
    Preset("PAN", 213, 213, 50),
    Preset("Exam form", 200, 230, 50),
)

class CropState {
    var z by mutableFloatStateOf(1f)
    var ox by mutableFloatStateOf(0f)
    var oy by mutableFloatStateOf(0f)
    var fw by mutableFloatStateOf(1f)
    var fh by mutableFloatStateOf(1f)

    private fun s0(bw: Int, bh: Int) = max(fw / bw, fh / bh)

    fun clamp(bw: Int, bh: Int) {
        val s = s0(bw, bh) * z
        val mx = max(0f, (bw * s - fw) / 2f); val my = max(0f, (bh * s - fh) / 2f)
        ox = ox.coerceIn(-mx, mx); oy = oy.coerceIn(-my, my)
    }

    /** Visible region in bitmap pixels. */
    fun rect(bw: Int, bh: Int): RectF {
        val s = s0(bw, bh) * z
        val l = (bw * s / 2f - fw / 2f - ox) / s
        val t = (bh * s / 2f - fh / 2f - oy) / s
        return RectF(l, t, l + fw / s, t + fh / s)
    }
}

@Composable
private fun CropBox(bmp: Bitmap, w: Int, h: Int, st: CropState) {
    val img = remember(bmp) { bmp.asImageBitmap() }
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(
            Modifier.fillMaxWidth(0.85f).aspectRatio(w.toFloat() / h)
                .border(2.dp, MaterialTheme.colorScheme.primary).clipToBounds()
                .onSizeChanged { st.fw = it.width.toFloat(); st.fh = it.height.toFloat(); st.clamp(bmp.width, bmp.height) }
                .pointerInput(bmp) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        st.z = (st.z * zoom).coerceIn(1f, 6f)
                        st.ox += pan.x; st.oy += pan.y
                        st.clamp(bmp.width, bmp.height)
                    }
                }
        ) {
            Image(
                img, null,
                Modifier.fillMaxSize().graphicsLayer { scaleX = st.z; scaleY = st.z; translationX = st.ox; translationY = st.oy },
                contentScale = ContentScale.Crop
            )
        }
    }
}

@Composable
fun PassportScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var picked by remember { mutableStateOf<PickedImage?>(null) }
    var sel by remember { mutableIntStateOf(0) }
    var wTxt by remember { mutableStateOf(presets[0].w.toString()) }
    var hTxt by remember { mutableStateOf(presets[0].h.toString()) }
    var kbTxt by remember { mutableStateOf(presets[0].kb.toString()) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var note by remember { mutableStateOf<String?>(null) }
    var result by remember { mutableStateOf<ByteArray?>(null) }
    val w = wTxt.toIntOrNull() ?: 0; val h = hTxt.toIntOrNull() ?: 0; val kb = kbTxt.toIntOrNull() ?: 0
    val valid = w in 20..3000 && h in 20..3000 && kb in 5..2000
    val crop = remember(picked?.uri, w, h) { CropState() }

    val pick = rememberImagePicker { uri ->
        scope.launch {
            busy = true; error = null; result = null; note = null
            val p = work { loadPicked(ctx, uri, 1600) }
            if (p == null) error = "Couldn't open that photo. Please choose a JPG or PNG image." else picked = p
            busy = false
        }
    }

    ToolScaffold("Passport Photo", nav) {
        Text("Size preset", style = MaterialTheme.typography.titleSmall)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            presets.forEachIndexed { i, p ->
                FilterChip(sel == i, {
                    sel = i; wTxt = p.w.toString(); hTxt = p.h.toString(); kbTxt = p.kb.toString(); result = null
                }, label = { Text(p.name) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NumberField(wTxt, "Width px", { wTxt = it; result = null }, Modifier.weight(1f))
            NumberField(hTxt, "Height px", { hTxt = it; result = null }, Modifier.weight(1f))
            NumberField(kbTxt, "Max KB", { kbTxt = it; result = null }, Modifier.weight(1f))
        }
        Text("Presets are common defaults. Check your form's exact rules and edit the numbers if needed.", style = MaterialTheme.typography.bodySmall)
        Button(onClick = pick, Modifier.fillMaxWidth(), enabled = !busy) { Text(if (picked == null) "Choose photo" else "Choose another photo") }

        val p = picked
        if (p != null && valid) {
            Text("Drag to move, pinch to zoom", style = MaterialTheme.typography.bodySmall)
            CropBox(p.bitmap, w, h, crop)
            Button(
                onClick = {
                    scope.launch {
                        busy = true; error = null; note = null
                        val res = work {
                            val out = Img.cropScale(p.bitmap, crop.rect(p.bitmap.width, p.bitmap.height), w, h)
                            Img.underKb(out, kb)
                        }
                        if (res == null) error = "Not enough memory for this photo. Try a smaller one."
                        else {
                            result = res.first
                            if (!res.second) note = "Couldn't reach ${kb} KB at ${w}×${h} px. Best result is ${formatSize(res.first.size.toLong())}. Try a smaller pixel size."
                        }
                        busy = false
                    }
                },
                enabled = !busy, modifier = Modifier.fillMaxWidth()
            ) { Text("Crop & resize") }
        } else if (p != null) ErrorText("Enter width and height between 20 and 3000 px, and a size of 5–2000 KB.")
        if (busy) BusyRow("Working…")
        error?.let { ErrorText(it) }
        note?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        result?.let { bytes ->
            SizeCompare(picked?.sizeBytes ?: -1, bytes.size.toLong())
            Text("Output: $w × $h px", fontWeight = FontWeight.Bold)
            ResultPreview(bytes)
            ExportRow(bytes, "image/jpeg", "Photo_${w}x$h")
        }
    }
}

// ---------- 7. Signature Resize ----------
@Composable
fun SignatureScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var picked by remember { mutableStateOf<PickedImage?>(null) }
    var wTxt by remember { mutableStateOf("140") }
    var hTxt by remember { mutableStateOf("60") }
    var kbTxt by remember { mutableStateOf("20") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var note by remember { mutableStateOf<String?>(null) }
    var result by remember { mutableStateOf<ByteArray?>(null) }
    val w = wTxt.toIntOrNull() ?: 0; val h = hTxt.toIntOrNull() ?: 0; val kb = kbTxt.toIntOrNull() ?: 0
    val valid = w in 20..3000 && h in 20..3000 && kb in 5..2000

    val pick = rememberImagePicker { uri ->
        scope.launch {
            busy = true; error = null; result = null; note = null
            val p = work { loadPicked(ctx, uri, 2400) }
            if (p == null) error = "Couldn't open that image. Please choose a JPG or PNG image." else picked = p
            busy = false
        }
    }

    ToolScaffold("Signature Resize", nav) {
        Button(onClick = pick, Modifier.fillMaxWidth(), enabled = !busy) { Text(if (picked == null) "Choose signature image" else "Choose another image") }
        picked?.let { PickedCard(it) }
        Text("Quick presets", style = MaterialTheme.typography.titleSmall)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            AssistChip({ wTxt = "140"; hTxt = "60"; kbTxt = "20"; result = null }, label = { Text("140×60 · 20 KB") })
            AssistChip({ wTxt = "354"; hTxt = "157"; kbTxt = "50"; result = null }, label = { Text("PAN 354×157 · 50 KB") })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NumberField(wTxt, "Width px", { wTxt = it; result = null }, Modifier.weight(1f))
            NumberField(hTxt, "Height px", { hTxt = it; result = null }, Modifier.weight(1f))
            NumberField(kbTxt, "Max KB", { kbTxt = it; result = null }, Modifier.weight(1f))
        }
        Text("Tip: sign on white paper with a dark pen and photograph it in good light.", style = MaterialTheme.typography.bodySmall)
        Button(
            onClick = {
                val p = picked ?: return@Button
                scope.launch {
                    busy = true; error = null; note = null
                    val res = work { Img.underKb(Img.fitOnCanvas(p.bitmap, w, h), kb) }
                    if (res == null) error = "Not enough memory for this image. Try a smaller one."
                    else {
                        result = res.first
                        if (!res.second) note = "Couldn't reach ${kb} KB at ${w}×${h} px. Best result is ${formatSize(res.first.size.toLong())}."
                    }
                    busy = false
                }
            },
            enabled = picked != null && valid && !busy, modifier = Modifier.fillMaxWidth()
        ) { Text("Resize signature") }
        if (picked != null && !valid) ErrorText("Enter width and height between 20 and 3000 px, and a size of 5–2000 KB.")
        if (busy) BusyRow("Working…")
        error?.let { ErrorText(it) }
        note?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        result?.let { bytes ->
            SizeCompare(picked?.sizeBytes ?: -1, bytes.size.toLong())
            Text("Output: $w × $h px", fontWeight = FontWeight.Bold)
            ResultPreview(bytes)
            ExportRow(bytes, "image/jpeg", "Signature")
        }
    }
}
