@file:OptIn(ExperimentalMaterial3Api::class)

package com.formtools.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Premium.init(this)
        History.load(this)
        Ads.init(this)
        setContent { FormToolsTheme { Surface(Modifier.fillMaxSize()) { AppNav() } } }
    }
}

@Composable
fun AppNav() {
    val nav = rememberNavController()
    NavHost(
        nav, startDestination = "home",
        // No animations: smoother on cheap phones
        enterTransition = { EnterTransition.None }, exitTransition = { ExitTransition.None },
        popEnterTransition = { EnterTransition.None }, popExitTransition = { ExitTransition.None }
    ) {
        composable("home") { HomeScreen(nav) }
        composable("history") { HistoryScreen(nav) }
        composable("premium") { PremiumScreen(nav) }
        composable("settings") { SettingsScreen(nav) }
        composable("qr_scan") { QrScannerScreen(nav) }
        composable("qr_gen") { QrGeneratorScreen(nav) }
        composable("photo_resize") { PhotoResizeScreen(nav) }
        composable("compress") { CompressScreen(nav) }
        composable("pdf") { ImageToPdfScreen(nav) }
        composable("passport") { PassportScreen(nav) }
        composable("signature") { SignatureScreen(nav) }
    }
}

// ---------- Home (no ads) ----------
class Tool(val route: String, val icon: String, val title: String, val sub: String)

private val tools = listOf(
    Tool("qr_scan", "📷", "QR Scanner", "Scan & history"),
    Tool("qr_gen", "🔲", "QR Generator", "Text or link"),
    Tool("photo_resize", "📐", "Photo Resize", "To an exact KB"),
    Tool("compress", "📉", "Image Compress", "Smaller files"),
    Tool("pdf", "📄", "Image to PDF", "Combine photos"),
    Tool("passport", "🆔", "Passport Photo", "Aadhaar, PAN, exams"),
    Tool("signature", "✒️", "Signature Resize", "KB + pixel size"),
)

@Composable
fun HomeScreen(nav: NavController) {
    TabScaffold(nav, "home", "Form Tools") { pad ->
        Column(Modifier.padding(pad)) {
            Text(
                "Free tools for forms & applications. Works offline.",
                Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                style = MaterialTheme.typography.bodyMedium
            )
            LazyVerticalGrid(
                GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(tools) { t ->
                    Card(onClick = { nav.navigate(t.route) }, Modifier.fillMaxWidth().height(124.dp)) {
                        Column(
                            Modifier.fillMaxSize().padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                        ) {
                            Text(t.icon, fontSize = 34.sp)
                            Spacer(Modifier.height(6.dp))
                            Text(t.title, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                            Text(t.sub, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
                        }
                    }
                }
            }
        }
    }
}

// ---------- Scan history ----------
@Composable
fun HistoryScreen(nav: NavController) {
    val ctx = LocalContext.current
    TabScaffold(nav, "history", "Scan History") { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 16.dp)) {
            if (History.items.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No scans yet. Scanned QR codes will appear here.", textAlign = TextAlign.Center)
                }
            } else {
                TextButton(onClick = { History.clear(ctx) }, Modifier.align(Alignment.End)) { Text("Clear all") }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(History.items.toList()) { item ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Text(item.text, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                                Text(formatTime(item.time), style = MaterialTheme.typography.bodySmall)
                                Row {
                                    TextButton(onClick = { copyText(ctx, item.text) }) { Text("Copy") }
                                    TextButton(onClick = { shareText(ctx, item.text) }) { Text("Share") }
                                    if (isHttp(item.text)) TextButton(onClick = { openUrl(ctx, item.text.trim()) }) { Text("Open") }
                                    Spacer(Modifier.weight(1f))
                                    TextButton(onClick = { History.remove(ctx, item) }) { Text("Delete") }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------- Premium ----------
@Composable
fun PremiumScreen(nav: NavController) {
    val ctx = LocalContext.current
    TabScaffold(nav, "premium", "Go Premium") { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (Premium.isPremium) {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Text("✅ You're Premium. Thank you!", Modifier.padding(16.dp), fontWeight = FontWeight.Bold)
                }
            }
            Text("Everything unlocked", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            listOf("🚫  No ads", "📚  Batch processing", "♾️  No daily limit", "✨  Higher quality (up to 100%)").forEach {
                Text(it, style = MaterialTheme.typography.bodyLarge)
            }
            PlanCard("₹49 / month", "Cancel anytime") { buy(ctx, "monthly") }
            PlanCard("₹399 lifetime", "Best value · pay once") { buy(ctx, "lifetime") }
            Text("Prices are placeholders.", style = MaterialTheme.typography.bodySmall)

            if (!Premium.isPremium && !Premium.sessionUnlock) {
                HorizontalDivider()
                OutlinedButton(
                    onClick = {
                        ctx.findActivity()?.let { a ->
                            Ads.showRewarded(a) { Premium.sessionUnlock = true; toast(ctx, "Batch processing unlocked for this session") }
                        }
                    },
                    Modifier.fillMaxWidth()
                ) { Text("Watch an ad to unlock batch processing (this session)") }
            }
            if (BuildConfig.DEBUG) {
                HorizontalDivider()
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Debug: isPremium", Modifier.weight(1f))
                    Switch(Premium.isPremium, { Premium.setPremium(ctx, it) })
                }
            }
        }
    }
}

@Composable
private fun PlanCard(price: String, note: String, onChoose: () -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(price, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(note, style = MaterialTheme.typography.bodySmall)
            }
            Button(onClick = onChoose) { Text("Choose") }
        }
    }
}

// TODO: Connect Samsung IAP (Galaxy Store) here. Call Premium.setPremium(ctx, true) only after a verified purchase.
private fun buy(ctx: android.content.Context, plan: String) {
    if (BuildConfig.DEBUG) { Premium.setPremium(ctx, true); toast(ctx, "Debug build: Premium enabled ($plan)") }
    else toast(ctx, "Purchases will be available soon.")
}

// ---------- Settings ----------
@Composable
fun SettingsScreen(nav: NavController) {
    val ctx = LocalContext.current
    var showAbout by remember { mutableStateOf(false) }
    TabScaffold(nav, "settings", "Settings") { pad ->
        Column(Modifier.padding(pad)) {
            SettingRow("Privacy Policy") { openUrl(ctx, Config.PRIVACY_URL) }
            SettingRow("Rate App") {
                try {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("samsungapps://ProductDetail/${BuildConfig.APPLICATION_ID}")))
                } catch (e: Exception) { openUrl(ctx, Config.STORE_URL) }
            }
            SettingRow("Share App") {
                shareText(ctx, "Form Tools: free QR, photo resize, PDF and passport photo tools for forms. ${Config.STORE_URL}")
            }
            SettingRow("About") { showAbout = true }
        }
    }
    if (showAbout) AlertDialog(
        onDismissRequest = { showAbout = false },
        title = { Text("Form Tools") },
        text = { Text("Version ${BuildConfig.VERSION_NAME}\n\nFree tools for students and job seekers. Your photos and files are processed on your phone and never uploaded.") },
        confirmButton = { TextButton(onClick = { showAbout = false }) { Text("OK") } }
    )
}

@Composable
private fun SettingRow(title: String, onClick: () -> Unit) {
    Column(Modifier.clickable(onClick = onClick)) {
        Text(title, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 18.dp), style = MaterialTheme.typography.bodyLarge)
        HorizontalDivider()
    }
}
