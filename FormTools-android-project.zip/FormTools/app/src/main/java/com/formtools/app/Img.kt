package com.formtools.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.provider.OpenableColumns
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayOutputStream
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

object Img {
    /** Decodes an image with memory-safe sampling, fixes EXIF rotation. Returns null on failure. */
    fun load(c: Context, uri: Uri, maxDim: Int): Bitmap? {
        return try {
            val cr = c.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > maxDim) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: return null

            val orientation = cr.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
            val m = Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            }
            if (!m.isIdentity) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            bmp
        } catch (e: Throwable) { null }
    }

    fun sizeOf(c: Context, uri: Uri): Long {
        try {
            c.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
                if (it.moveToFirst() && !it.isNull(0)) return it.getLong(0)
            }
            c.contentResolver.openAssetFileDescriptor(uri, "r")?.use { return it.length }
        } catch (e: Exception) { /* fall through */ }
        return -1L
    }

    fun preview(bytes: ByteArray): Bitmap? = try {
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = 2 })
    } catch (e: Throwable) { null }

    /** JPEG has no transparency, so paint transparent images on white first. */
    fun flatten(src: Bitmap): Bitmap {
        if (!src.hasAlpha()) return src
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        Canvas(out).apply { drawColor(Color.WHITE); drawBitmap(src, 0f, 0f, null) }
        return out
    }

    fun jpeg(bmp: Bitmap, quality: Int): ByteArray {
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, quality, out)
        return out.toByteArray()
    }

    fun png(bmp: Bitmap): ByteArray {
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        return out.toByteArray()
    }

    /** Best quality that fits under targetBytes; shrinks pixel size if quality alone can't reach it. */
    fun toTargetSize(src: Bitmap, targetBytes: Int): ByteArray {
        var bmp = flatten(src)
        repeat(12) {
            var lo = 5; var hi = 95
            var best: ByteArray? = null
            while (lo <= hi) {
                val mid = (lo + hi) / 2
                val data = jpeg(bmp, mid)
                if (data.size <= targetBytes) { best = data; lo = mid + 1 } else hi = mid - 1
            }
            if (best != null) return best
            bmp = Bitmap.createScaledBitmap(
                bmp, max(16, (bmp.width * 0.85f).toInt()), max(16, (bmp.height * 0.85f).toInt()), true
            )
        }
        return jpeg(bmp, 5)
    }

    /** Keeps pixel size fixed; only varies quality. Boolean = reached the target. */
    fun underKb(src: Bitmap, targetKb: Int): Pair<ByteArray, Boolean> {
        val bmp = flatten(src)
        val target = targetKb * 1024
        var lo = 1; var hi = 95
        var best: ByteArray? = null
        while (lo <= hi) {
            val mid = (lo + hi) / 2
            val data = jpeg(bmp, mid)
            if (data.size <= target) { best = data; lo = mid + 1 } else hi = mid - 1
        }
        return best?.let { it to true } ?: (jpeg(bmp, 1) to false)
    }

    /** Fit the whole image inside an exact w x h white canvas. */
    fun fitOnCanvas(src: Bitmap, w: Int, h: Int): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(Color.WHITE)
        val s = min(w / src.width.toFloat(), h / src.height.toFloat())
        val dw = src.width * s; val dh = src.height * s
        val l = (w - dw) / 2f; val t = (h - dh) / 2f
        c.drawBitmap(src, null, RectF(l, t, l + dw, t + dh), Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    fun cropScale(src: Bitmap, r: RectF, outW: Int, outH: Int): Bitmap {
        val l = r.left.roundToInt().coerceIn(0, src.width - 1)
        val t = r.top.roundToInt().coerceIn(0, src.height - 1)
        val w = r.width().roundToInt().coerceIn(1, src.width - l)
        val h = r.height().roundToInt().coerceIn(1, src.height - t)
        val cropped = Bitmap.createBitmap(src, l, t, w, h)
        return Bitmap.createScaledBitmap(cropped, outW, outH, true)
    }
}

/** Minimal PDF writer that embeds JPEGs directly, so PDFs stay small (important for form uploads). */
object PdfBuilder {
    private const val PW = 595f
    private const val PH = 842f
    private const val MARGIN = 24f

    fun build(c: Context, uris: List<Uri>, maxDim: Int, quality: Int): ByteArray? {
        val pages = uris.mapNotNull { uri ->
            val b = Img.load(c, uri, maxDim) ?: return@mapNotNull null
            val flat = Img.flatten(b)
            val r = Triple(Img.jpeg(flat, quality), flat.width, flat.height)
            if (flat !== b) flat.recycle()
            b.recycle()
            r
        }
        if (pages.isEmpty()) return null
        val n = pages.size
        val out = ByteArrayOutputStream()
        val offs = IntArray(3 + n * 3)
        fun w(s: String) = out.write(s.toByteArray(Charsets.ISO_8859_1))
        fun begin(num: Int) { offs[num] = out.size(); w("$num 0 obj\n") }
        fun end() = w("endobj\n")

        w("%PDF-1.4\n")
        begin(1); w("<< /Type /Catalog /Pages 2 0 R >>\n"); end()
        begin(2)
        w("<< /Type /Pages /Count $n /Kids [" + (0 until n).joinToString(" ") { "${3 + it * 3} 0 R" } + "] >>\n")
        end()
        pages.forEachIndexed { i, (data, pw, ph) ->
            val base = 3 + i * 3
            val s = min((PW - 2 * MARGIN) / pw, (PH - 2 * MARGIN) / ph)
            val dw = pw * s; val dh = ph * s
            val content = String.format(Locale.US, "q %.2f 0 0 %.2f %.2f %.2f cm /Im0 Do Q", dw, dh, (PW - dw) / 2, (PH - dh) / 2)
            begin(base)
            w("<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /XObject << /Im0 ${base + 2} 0 R >> >> /Contents ${base + 1} 0 R >>\n")
            end()
            begin(base + 1)
            w("<< /Length ${content.length} >>\nstream\n$content\nendstream\n")
            end()
            begin(base + 2)
            w("<< /Type /XObject /Subtype /Image /Width $pw /Height $ph /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${data.size} >>\nstream\n")
            out.write(data)
            w("\nendstream\n")
            end()
        }
        val xref = out.size()
        val total = 3 + n * 3
        w("xref\n0 $total\n0000000000 65535 f \n")
        for (i in 1 until total) w(String.format(Locale.US, "%010d 00000 n \n", offs[i]))
        w("trailer\n<< /Size $total /Root 1 0 R >>\nstartxref\n$xref\n%%EOF\n")
        return out.toByteArray()
    }
}
