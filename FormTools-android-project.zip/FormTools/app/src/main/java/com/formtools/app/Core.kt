package com.formtools.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.SystemClock
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ---------- Config (edit these) ----------
object Config {
    const val PRIVACY_URL = "https://singhabha097-ops.github.io/Form-tool/" 
    val STORE_URL get() = "https://galaxystore.samsung.com/detail/${BuildConfig.APPLICATION_ID}"
}

// ---------- Premium ----------
object Premium {
    const val FREE_DAILY_LIMIT = 10 // free saves per day

    /** Global flag. When true: no ads, everything unlocked. */
    var isPremium by mutableStateOf(false)
        private set

    /** Set by watching a rewarded ad. Lasts until the app process is closed. */
    var sessionUnlock by mutableStateOf(false)

    val batchUnlocked get() = isPremium || sessionUnlock
    val maxQuality get() = if (isPremium) 100 else 80

    private fun prefs(c: Context) = c.getSharedPreferences("ft_prefs", Context.MODE_PRIVATE)

    fun init(c: Context) { isPremium = prefs(c).getBoolean("premium", false) }

    // TODO: call this only after a verified purchase (Samsung IAP for Galaxy Store).
    fun setPremium(c: Context, value: Boolean) {
        isPremium = value
        prefs(c).edit().putBoolean("premium", value).apply()
    }

    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun usedToday(c: Context): Int {
        val p = prefs(c)
        return if (p.getString("day", "") == today()) p.getInt("count", 0) else 0
    }

    fun guardExport(c: Context): Boolean {
        if (isPremium) return true
        if (usedToday(c) >= FREE_DAILY_LIMIT) {
            toast(c, "Daily limit of $FREE_DAILY_LIMIT free saves reached. Go Premium for no limit.")
            return false
        }
        return true
    }

    fun recordExport(c: Context) {
        if (isPremium) return
        prefs(c).edit().putString("day", today()).putInt("count", usedToday(c) + 1).apply()
    }
}

// ---------- Ads (AdMob TEST IDs) ----------
object Ads {
    const val BANNER = "ca-app-pub-4711792489262451/9714503136"
    const val INTERSTITIAL = "ca-app-pub-4711792489262451/2097059532"
    const val REWARDED = "ca-app-pub-4711792489262451/7826706394"
    private const val MIN_GAP_MS = 120_000L

    private var interstitial: InterstitialAd? = null
    private var rewarded: RewardedAd? = null
    private var lastShown = -MIN_GAP_MS

    fun init(c: Context) {
        if (Premium.isPremium) return
        MobileAds.initialize(c) { loadInterstitial(c); loadRewarded(c) }
    }

    private fun loadInterstitial(c: Context) {
        InterstitialAd.load(c, INTERSTITIAL, AdRequest.Builder().build(), object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(ad: InterstitialAd) { interstitial = ad }
            override fun onAdFailedToLoad(e: LoadAdError) { interstitial = null }
        })
    }

    private fun loadRewarded(c: Context) {
        RewardedAd.load(c, REWARDED, AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
            override fun onAdLoaded(ad: RewardedAd) { rewarded = ad }
            override fun onAdFailedToLoad(e: LoadAdError) { rewarded = null }
        })
    }

    /** Shows an interstitial after a save/export, at most once every 2 minutes. */
    fun showInterstitialIfDue(a: Activity) {
        if (Premium.isPremium) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastShown < MIN_GAP_MS) return
        val ad = interstitial ?: return
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { interstitial = null; loadInterstitial(a.applicationContext) }
            override fun onAdFailedToShowFullScreenContent(e: AdError) { interstitial = null; loadInterstitial(a.applicationContext) }
        }
        lastShown = now
        ad.show(a)
    }

    /** User-initiated only. Calls onReward when the user earns the reward. */
    fun showRewarded(a: Activity, onReward: () -> Unit) {
        val ad = rewarded
        if (ad == null) {
            toast(a, "Ad isn't ready yet. Please try again in a moment.")
            loadRewarded(a.applicationContext)
            return
        }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() { rewarded = null; loadRewarded(a.applicationContext) }
        }
        rewarded = null
        ad.show(a) { onReward() }
    }
}

// ---------- Scan history ----------
class ScanItem(val text: String, val time: Long)

object History {
    val items = mutableStateListOf<ScanItem>()
    private fun prefs(c: Context) = c.getSharedPreferences("ft_history", Context.MODE_PRIVATE)

    fun load(c: Context) {
        items.clear()
        try {
            val arr = JSONArray(prefs(c).getString("items", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                items.add(ScanItem(o.getString("t"), o.getLong("ts")))
            }
        } catch (e: Exception) { /* ignore corrupt history */ }
    }

    private fun save(c: Context) {
        val arr = JSONArray()
        items.forEach { arr.put(JSONObject().put("t", it.text).put("ts", it.time)) }
        prefs(c).edit().putString("items", arr.toString()).apply()
    }

    fun add(c: Context, text: String) {
        items.removeAll { it.text == text }
        items.add(0, ScanItem(text, System.currentTimeMillis()))
        while (items.size > 100) items.removeAt(items.lastIndex)
        save(c)
    }

    fun remove(c: Context, item: ScanItem) { items.remove(item); save(c) }
    fun clear(c: Context) { items.clear(); save(c) }
}

// ---------- Small helpers ----------
fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) { if (c is Activity) return c; c = c.baseContext }
    return null
}

fun toast(c: Context, msg: String) = Toast.makeText(c, msg, Toast.LENGTH_LONG).show()

fun formatSize(bytes: Long): String = when {
    bytes < 0 -> "—"
    bytes < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", bytes / 1024.0)
    else -> String.format(Locale.US, "%.2f MB", bytes / 1048576.0)
}

fun formatTime(ms: Long): String = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(ms))

fun copyText(c: Context, text: String) {
    val cm = c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("Form Tools", text))
    toast(c, "Copied")
}

fun shareText(c: Context, text: String) {
    val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
    c.startActivity(Intent.createChooser(i, "Share via"))
}

fun openUrl(c: Context, url: String) {
    try { c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    catch (e: ActivityNotFoundException) { toast(c, "No app found to open this link.") }
}

fun isHttp(s: String) = s.trim().startsWith("http", ignoreCase = true)

// ---------- File saving / sharing ----------
object Files {
    fun save(c: Context, bytes: ByteArray, name: String, mime: String): Boolean {
        return try {
            val isPdf = mime == "application/pdf"
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, mime)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, if (isPdf) "Download/FormTools" else "Pictures/FormTools")
                }
                val collection = if (isPdf) MediaStore.Downloads.EXTERNAL_CONTENT_URI
                else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                val uri = c.contentResolver.insert(collection, values) ?: return false
                val out = c.contentResolver.openOutputStream(uri) ?: return false
                out.use { it.write(bytes) }
                true
            } else {
                val base = Environment.getExternalStoragePublicDirectory(
                    if (isPdf) Environment.DIRECTORY_DOWNLOADS else Environment.DIRECTORY_PICTURES
                )
                val dir = File(base, "FormTools").apply { mkdirs() }
                val f = File(dir, name)
                f.writeBytes(bytes)
                MediaScannerConnection.scanFile(c, arrayOf(f.path), arrayOf(mime), null)
                true
            }
        } catch (e: Exception) { false }
    }

    fun share(c: Context, bytes: ByteArray, name: String, mime: String) {
        try {
            val dir = File(c.cacheDir, "shared").apply { mkdirs() }
            dir.listFiles()?.forEach { it.delete() }
            val f = File(dir, name)
            f.writeBytes(bytes)
            val uri = FileProvider.getUriForFile(c, "${c.packageName}.fileprovider", f)
            val i = Intent(Intent.ACTION_SEND).apply {
                type = mime
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            c.startActivity(Intent.createChooser(i, "Share via"))
        } catch (e: Exception) { toast(c, "Couldn't share this file. Please try again.") }
    }
}
