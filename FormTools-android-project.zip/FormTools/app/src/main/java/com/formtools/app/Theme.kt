package com.formtools.app

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun FormToolsTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) {
        darkColorScheme(primary = Color(0xFF90CAF9), onPrimary = Color(0xFF002B52), secondary = Color(0xFFFFB74D))
    } else {
        lightColorScheme(
            primary = Color(0xFF1565C0), secondary = Color(0xFFFF8F00),
            background = Color(0xFFF6F8FB), surface = Color(0xFFF6F8FB)
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
