# Form Tools (Android, Kotlin + Jetpack Compose)

## Open & run
1. Open this folder in Android Studio (Koala or newer). Let Gradle sync (it generates the Gradle wrapper).
2. Run on a device. Debug builds show a "Debug: isPremium" switch on the Premium tab for testing.

## Make a signed release (APK / AAB)
1. Build > Generate Signed Bundle / APK... and create a keystore (KEEP IT SAFE; you need the same one for every update).
   Or copy `keystore.properties.example` to `keystore.properties`, fill it in, then run:
   `./gradlew assembleRelease` (APK) or `./gradlew bundleRelease` (AAB)
2. Output: app/build/outputs/apk/release/ or app/build/outputs/bundle/release/

## Before publishing: replace these placeholders
- AdMob test IDs: `Core.kt` (Ads.BANNER / INTERSTITIAL / REWARDED) and the App ID in `AndroidManifest.xml`
- `Config.PRIVACY_URL` in `Core.kt` (a real privacy policy is required, and must mention AdMob)
- `applicationId` in `app/build.gradle.kts`
- App icon: `res/drawable/ic_launcher.xml` is a simple placeholder
- Billing: `buy()` in `App.kt`. For Galaxy Store use Samsung IAP, not Google Play Billing.
  Call `Premium.setPremium(ctx, true)` only after a verified purchase.
- Free daily save limit: `Premium.FREE_DAILY_LIMIT` (default 10)
- Passport/Aadhaar/PAN/exam presets: `presets` in `ImageTools.kt` (verify against each form)
